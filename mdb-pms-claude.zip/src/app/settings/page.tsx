export default function SettingsPage() {

  return (

    <main>

      <h1>
        Instellingen
      </h1>


      <p>
        MDB PMS
      </p>


      <section>

        <h2>
          Systeem instellingen
        </h2>


        <div>
          Bedrijfsgegevens
        </div>

        <div>
          Gebruikersrollen
        </div>

        <div>
          Workflow instellingen
        </div>

        <div>
          Integraties
        </div>


      </section>


    </main>

  );

}